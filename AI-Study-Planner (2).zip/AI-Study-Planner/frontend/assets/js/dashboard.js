const ctx = document.getElementById("studyChart");

if (ctx) {

    new Chart(ctx, {

        type: "line",

        data: {

            labels: [

                "Mon",
                "Tue",
                "Wed",
                "Thu",
                "Fri",
                "Sat",
                "Sun"

            ],

            datasets: [{

                label: "Study Hours",

                data: [

                    2,
                    3,
                    1,
                    4,
                    5,
                    2,
                    6

                ],

                borderColor: "#2563eb",

                backgroundColor: "rgba(37,99,235,.15)",

                tension: .4,

                fill: true

            }]

        },


options: {

    responsive: true,

    maintainAspectRatio: false,

    plugins: {

        legend: {

            display: true,

            labels: {

                color:"#ffffff"

            }

        }

    },

    scales:{

        x:{

            ticks:{

                color:"#cbd5e1"

            },

            grid:{

                color:"rgba(255,255,255,.05)"

            }

        },

        y:{

            beginAtZero:true,

            ticks:{

                color:"#cbd5e1"

            },

            grid:{

                color:"rgba(255,255,255,.05)"

            }

        }

    }

}            
        

    });

}

// =========================
// Load User Name
// =========================

const user = JSON.parse(localStorage.getItem("studyPlannerUser"));

if(user){

    document.getElementById("userName").innerText=user.fullName;

}

// =========================
// Profile Dropdown
// =========================

const profileBtn=document.getElementById("profileBtn");

const profileMenu=document.getElementById("profileMenu");



  if(profileBtn && profileMenu){

    profileBtn.onclick=()=>{

        profileMenu.classList.toggle("show");

    };

}

// =========================
// Dark Mode
// =========================

const darkBtn=document.querySelector(".fa-moon");

if(darkBtn){

    darkBtn.parentElement.onclick=()=>{

        document.body.classList.toggle("light-mode");

    };

}

// =========================
// Sidebar Toggle
// =========================

const menuBtn=document.getElementById("menuToggle");



   if(menuBtn){

    menuBtn.onclick=()=>{

        document.querySelector(".sidebar").classList.toggle("show");

    };

}

// =========================
// Logout
// =========================

const logoutBtn = document.getElementById("logoutBtn");

if(logoutBtn){

    logoutBtn.onclick=()=>{

        localStorage.removeItem("isLoggedIn");

        localStorage.removeItem("studyPlannerUser");

        window.location.href="login.html";

    };

}